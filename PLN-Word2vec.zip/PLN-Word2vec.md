# <font color='blue'> Machine Learning</font>

# <font color='blue'> Processamento de Linguagem Natural</font>


```python
# Versão da Linguagem Python
from platform import python_version
print('Versão da Linguagem Python Usada Neste Jupyter Notebook:', python_version())
```

    Versão da Linguagem Python Usada Neste Jupyter Notebook: 3.8.8
    

## Estudo de Caso - Previsão de Palavras com Base no Contexto e Visualização com PCA


![title](imagens/word2vec.png)


```python
# Para atualizar um pacote, execute o comando abaixo no terminal ou prompt de comando:
# pip install -U nome_pacote

# Para instalar a versão exata de um pacote, execute o comando abaixo no terminal ou prompt de comando:
# !pip install torch==1.5.0

# Depois de instalar ou atualizar o pacote, reinicie o jupyter notebook.

# Instala o pacote watermark. 
# Esse pacote é usado para gravar as versões de outros pacotes usados neste jupyter notebook.
!pip install -q -U watermark
```


```python
# Instala o PyTorch
!pip install -q torch 
```


```python
# Pacote para gráficos com Scikit-learn
!pip install -q scikit-plot
```


```python
# Imports
import torch
import scipy
import sklearn
import scikitplot
import numpy as np
import torch.nn.functional as F
from torch.optim import SGD
from torch.autograd import Variable, profiler
from sklearn.decomposition import PCA
from scipy.spatial.distance import cosine
from scikitplot.decomposition import plot_pca_2d_projection
%matplotlib inline
```

### Preparação dos Dados


```python
# Corpus
corpus = ['ele é um rei',
          'ela é uma rainha',
          'ele é um homem',
          'ela é uma mulher',
          'Madrid é a capital da Espanha',
          'Berlim é a capital da Alemanha',
          'Lisboa é a capital de Portugal']
```


```python
# Construindo o vocabulário com tokenização
palavras = []
for sentence in corpus:
    for palavra in sentence.split():
         if palavra not in palavras:
            palavras.append(palavra)
```


```python
# Visualiza os dados
palavras
```




    ['ele',
     'é',
     'um',
     'rei',
     'ela',
     'uma',
     'rainha',
     'homem',
     'mulher',
     'Madrid',
     'a',
     'capital',
     'da',
     'Espanha',
     'Berlim',
     'Alemanha',
     'Lisboa',
     'de',
     'Portugal']




```python
# Criamos o mapeamento palavra - índice   
word2idx = {w:idx for (idx, w) in enumerate(palavras)}
word2idx
```




    {'ele': 0,
     'é': 1,
     'um': 2,
     'rei': 3,
     'ela': 4,
     'uma': 5,
     'rainha': 6,
     'homem': 7,
     'mulher': 8,
     'Madrid': 9,
     'a': 10,
     'capital': 11,
     'da': 12,
     'Espanha': 13,
     'Berlim': 14,
     'Alemanha': 15,
     'Lisboa': 16,
     'de': 17,
     'Portugal': 18}




```python
# Criamos o mapeamento inverso índice - palavra
idx2word = {idx:w for (idx, w) in enumerate(palavras)}
idx2word
```




    {0: 'ele',
     1: 'é',
     2: 'um',
     3: 'rei',
     4: 'ela',
     5: 'uma',
     6: 'rainha',
     7: 'homem',
     8: 'mulher',
     9: 'Madrid',
     10: 'a',
     11: 'capital',
     12: 'da',
     13: 'Espanha',
     14: 'Berlim',
     15: 'Alemanha',
     16: 'Lisboa',
     17: 'de',
     18: 'Portugal'}




```python
# Tamanho do vocabulário
tamanho_vocab = len(word2idx)
tamanho_vocab
```




    19



### Construção do Modelo


```python
# Função para gerar os embeddings
def get_word_embedding(word):
    word_vec_one_hot = np.zeros(tamanho_vocab)
    word_vec_one_hot[word2idx[word]] = 1
    return word_vec_one_hot
```


```python
# Função para gerar os vetores, da palavra central e do contexto
def gera_vetores():
    for sentence in corpus:
        words = sentence.split()
        indices = [word2idx[w] for w in words]
        
        # Loop pelo range de índices
        # Aqui geramos o vetor da palavra central em i
        # E geramos o vetor de contexto
        for i in range(len(indices)):
            for w in range(-window_size, window_size + 1):
                context_idx = i + w
                if context_idx < 0 or context_idx >= len(indices) or i == context_idx:
                    continue
                    
                # Gera os vetores    
                center_vec_one_hot = np.zeros(tamanho_vocab)
                center_vec_one_hot[indices[i]] = 1
                context_idx = indices[context_idx]
                                
                yield center_vec_one_hot, context_idx
```


```python
# Hiperparâmetros
embedding_dims = 10
window_size = 2
```

Definição dos pesos da rede neural.

- W1 é uma matriz de pesos de dimensões embedding_dims x tamanho_vocab
- W2 é uma matriz de pesos de dimensões tamanho_vocab x embedding_dims

Os pesos (ou coeficientes ou parâmetros) é aquilo que a rede aprende durante o treinamento. Como no início não sabemos qual o valor ideal de pesos (isso é o que queremos descobrir) iniciamos com valores randômicos usando torch.randn().

Ao final do aprendizado, o modelo em si nada mais é do que os valores ideais de W1 e W2.


```python
# Definição dos pesos da rede neural
W1 = Variable(torch.randn(embedding_dims, tamanho_vocab).float(), requires_grad = True)
W2 = Variable(torch.randn(tamanho_vocab, embedding_dims).float(), requires_grad = True)
```


```python
# Treinamento
print("\nIniciando o Treinamento...\n")
for epoch in range(1001):
    
    # Inicializa o erro médio da rede
    avg_loss = 0
    
    # Inicializa o controle do número de amostras
    samples = 0
    
    # Loop pelos dados (vetores de entrada)
    for data, target in gera_vetores():
        
        # Coleta x (vetor da palavra central)
        x = Variable(torch.from_numpy(data)).float()
        
        # Coleta y (vetor do contexto)
        y_true = Variable(torch.from_numpy(np.array([target])).long())
        
        # Atualiza o número de amostras
        samples += len(y_true)
        
        # Resultado da multiplicação entre os pesos e as primeiras camadas da rede
        a1 = torch.matmul(W1, x)
        a2 = torch.matmul(W2, a1)

        # A função softmax entrega a probabilidade da previsão da rede
        log_softmax = F.log_softmax(a2, dim = 0)

        # Previsão da rede
        network_pred_dist = F.softmax(log_softmax, dim = 0)
        
        # Calcula o erro, comparando a previsão da rede com o valor real 
        # (como fazemos em qualquer modelo de aprendizagem supervisionada)
        loss = F.nll_loss(log_softmax.view(1,-1), y_true)
        
        # Erro médio
        avg_loss += loss.item()
        
        # Inicia o backpropagation
        loss.backward()

        # Atualiza o valor dos pesos para a próxima passada
        W1.data -= 0.002 * W1.grad.data
        W2.data -= 0.002 * W2.grad.data

        # Zera o valor do gradiente depois de atualizar os pesos
        W1.grad.data.zero_()
        W2.grad.data.zero_()
        
    # Imprime o erro da rede
    if epoch % 10 == 0:
        print('Erro de Treinamento:', avg_loss / samples)

print("\nTreinamento Concluído.")
```

    
    Iniciando o Treinamento...
    
    Erro de Treinamento: 6.999760755833159
    Erro de Treinamento: 4.702029946002554
    Erro de Treinamento: 3.915885592394687
    Erro de Treinamento: 3.43886466038988
    Erro de Treinamento: 3.1123722411216574
    Erro de Treinamento: 2.8703637611358723
    Erro de Treinamento: 2.6860356790588256
    Erro de Treinamento: 2.540839285926616
    Erro de Treinamento: 2.4213597977415042
    Erro de Treinamento: 2.3202443107011472
    Erro de Treinamento: 2.2335681262168476
    Erro de Treinamento: 2.1592592907712813
    Erro de Treinamento: 2.0959958072672498
    Erro de Treinamento: 2.0423729727242854
    Erro de Treinamento: 1.9967002808413608
    Erro de Treinamento: 1.9573119000551549
    Erro de Treinamento: 1.9228522596841162
    Erro de Treinamento: 1.892325871802391
    Erro de Treinamento: 1.8650123667209706
    Erro de Treinamento: 1.8403717124081673
    Erro de Treinamento: 1.8179922791871619
    Erro de Treinamento: 1.797563023389654
    Erro de Treinamento: 1.778862807978975
    Erro de Treinamento: 1.7617401068514966
    Erro de Treinamento: 1.7460887463802988
    Erro de Treinamento: 1.731825941420616
    Erro de Treinamento: 1.7188726524089246
    Erro de Treinamento: 1.707141303001566
    Erro de Treinamento: 1.6965336793280663
    Erro de Treinamento: 1.6869440002644316
    Erro de Treinamento: 1.6782643496990204
    Erro de Treinamento: 1.6703899375935818
    Erro de Treinamento: 1.6632234137108985
    Erro de Treinamento: 1.6566772695551528
    Erro de Treinamento: 1.6506745352389964
    Erro de Treinamento: 1.6451490014157397
    Erro de Treinamento: 1.6400443372574258
    Erro de Treinamento: 1.6353125362954242
    Erro de Treinamento: 1.6309129132869395
    Erro de Treinamento: 1.6268110249904877
    Erro de Treinamento: 1.6229772352157754
    Erro de Treinamento: 1.6193859925929537
    Erro de Treinamento: 1.6160149644029902
    Erro de Treinamento: 1.6128444766744654
    Erro de Treinamento: 1.6098575782268605
    Erro de Treinamento: 1.6070391966941509
    Erro de Treinamento: 1.604376086529265
    Erro de Treinamento: 1.6018558410888022
    Erro de Treinamento: 1.5994679287393043
    Erro de Treinamento: 1.5972028450762972
    Erro de Treinamento: 1.5950517286645605
    Erro de Treinamento: 1.593006766856985
    Erro de Treinamento: 1.591060868603118
    Erro de Treinamento: 1.5892075439716906
    Erro de Treinamento: 1.5874409998985046
    Erro de Treinamento: 1.5857557470494128
    Erro de Treinamento: 1.5841471330916628
    Erro de Treinamento: 1.5826104695492602
    Erro de Treinamento: 1.5811417996883392
    Erro de Treinamento: 1.5797371991137241
    Erro de Treinamento: 1.5783933109425483
    Erro de Treinamento: 1.5771066368894373
    Erro de Treinamento: 1.5758742810563837
    Erro de Treinamento: 1.5746935650389244
    Erro de Treinamento: 1.5735616810778355
    Erro de Treinamento: 1.5724763724398105
    Erro de Treinamento: 1.5714352701572663
    Erro de Treinamento: 1.5704361124241606
    Erro de Treinamento: 1.5694768961439742
    Erro de Treinamento: 1.5685557995704895
    Erro de Treinamento: 1.5676709553028674
    Erro de Treinamento: 1.5668206633405481
    Erro de Treinamento: 1.5660033752309515
    Erro de Treinamento: 1.5652173700484824
    Erro de Treinamento: 1.564461313663645
    Erro de Treinamento: 1.5637337375194469
    Erro de Treinamento: 1.5630334983480738
    Erro de Treinamento: 1.5623591967085575
    Erro de Treinamento: 1.5617096690421408
    Erro de Treinamento: 1.5610837739832857
    Erro de Treinamento: 1.5604804551347773
    Erro de Treinamento: 1.5598987359949883
    Erro de Treinamento: 1.559337578555371
    Erro de Treinamento: 1.5587961077690125
    Erro de Treinamento: 1.5582732729455258
    Erro de Treinamento: 1.5577682884449655
    Erro de Treinamento: 1.5572803717978456
    Erro de Treinamento: 1.5568089263236269
    Erro de Treinamento: 1.5563531606755359
    Erro de Treinamento: 1.5559120704518987
    Erro de Treinamento: 1.5554854533773788
    Erro de Treinamento: 1.5550724470869024
    Erro de Treinamento: 1.554672475190873
    Erro de Treinamento: 1.5542849822247282
    Erro de Treinamento: 1.5539095731491739
    Erro de Treinamento: 1.5535456607950495
    Erro de Treinamento: 1.5531927347183228
    Erro de Treinamento: 1.5528503136431917
    Erro de Treinamento: 1.5525179841416947
    Erro de Treinamento: 1.5521954164860097
    Erro de Treinamento: 1.5518822333914168
    
    Treinamento Concluído.
    

### Teste do Modelo e Redução de Dimensionalidade com PCA

Para testar o modelo, tudo que precisamos é dos pesos, em nosso exemplo W1 e W2. Mas visualizar os dados é desafiador, pois a dimensionalidade é alta e quanto maior o número de palavras do vocabulário, mais complicado.

Uma alternativa, é reduzir a diemensionalidade dos dados. Convertemos todos os atributos em 2 componentes principais usando PCA (Principal Component Analysis) e com 2 componentes podemos visualizar os dados.

Cada componentes principal nada mais é do que a junção matemática da informação em outras variáveis. O PCA é um algoritmo de Machine Learning por si mesmo, da categoria de aprendizagem não supervisionada.

Vamos aplicar o PCA para visualizar os dados.


```python
# Cria o objeto para redução de dimensionalidade
pca = PCA(n_components = 2)
```


```python
# Treina o modelo PCA
pca.fit(W1.data.numpy().T)
```




    PCA(n_components=2)




```python
# Calcula a projeção PCA para o Plot
proj = pca.transform(W1.data.numpy().T)
```


```python
# Plot
ax = plot_pca_2d_projection(pca, 
                            W1.data.numpy().T, 
                            np.array(palavras), 
                            feature_labels = palavras, 
                            figsize = (16,10), 
                            text_fontsize = 12)

# Legenda
for i, txt in enumerate(palavras):
    ax.annotate(txt, (proj[i,0], proj[i,1]), size = 15)
```


    
![png](output_25_0.png)
    


Observe a legenda no gráfico acima! Palavras similares com base no contexto, estão com a "bolinha" com cores parecidas. No topo da lista temos países e cidades, depois pronomes e a palavra "capital", temos então homem, mulher, rainha e rei e por fim artigos e um verbo.

Tudo isso foi aprendido pela rede com base no contexto, que nada mais é do que a distância de cosseno entre as embeddings, os vetores que representam as palavras.

A visualização acima mostra que palavras que estão na mesma direção possui alguma similaridade, por exemplo "Alemanha" e "Berlim". Passe uma linha reta imaginária que "corta" as palavras "Alemanha" e "Berlim". Consegue? Se a resposta for sim, as palavras são similares. Abaixo terá outro exemplo.

Vamos extrair as distâncias com base na pergunta:

**Espanha está para Madrid, assim como Alemanha está para ?**

Vamos perguntar ao modelo.


```python
# Função para obter um vetor de palavras no peso W1 (esse é o contexto)
def get_word_vector_v(word):
    return W1[:, word2idx[word]].data.numpy()
```


```python
# Função para obter um vetor de palavras no peso W2 (essa é a palavra central)
def get_word_vector_u(word):
    return W2[word2idx[word],:].data.numpy()
```


```python
# Vamos obter os vetores das palavras
espanha = 1 * get_word_vector_v('Espanha') + 1 * get_word_vector_u('Espanha')
alemanha = 1 * get_word_vector_v('Alemanha') + 1 * get_word_vector_u('Alemanha') 
madrid = 1 * get_word_vector_v('Madrid') + 1 * get_word_vector_u('Madrid') 
```


```python
# Resultado
resultado = madrid - espanha + alemanha
```


```python
# Este é o resultado, ou seja, uma embedding que representa a palavra mais similar à palavra "Alemanha",
# com base na similaridade (contexto) entre "Polônia" e "Varsóvia".
resultado
```




    array([ 2.4778423 ,  1.561895  , -0.99088025, -2.5488174 ,  1.6821555 ,
            0.6689639 , -1.9104964 , -2.0957108 ,  1.3329777 , -3.1428251 ],
          dtype=float32)




```python
# Vamos extrair as distâncias de todas as outras palavras para a nossa palavra "secreta" que está 
# no vetor embedding chamado "resultado"
# Usamos a função cosine() do SciPy para calcular as distâncias
distancias = [(v, cosine(resultado, 1 * get_word_vector_u(v) + 1 * get_word_vector_v(v))) for v in palavras]
```


```python
# Visualiza as distâncias
distancias
```




    [('ele', 0.651717483997345),
     ('é', 0.5998729467391968),
     ('um', 0.6919193267822266),
     ('rei', 0.1476835012435913),
     ('ela', 1.3008829057216644),
     ('uma', 1.2741429507732391),
     ('rainha', 1.04703726246953),
     ('homem', 0.9079287946224213),
     ('mulher', 1.3129161894321442),
     ('Madrid', 0.2988954186439514),
     ('a', 0.4737280011177063),
     ('capital', 1.1034334897994995),
     ('da', 0.8640673011541367),
     ('Espanha', 1.3585205674171448),
     ('Berlim', 0.7608835995197296),
     ('Alemanha', 0.9178348556160927),
     ('Lisboa', 0.7098842263221741),
     ('de', 0.880749024450779),
     ('Portugal', 1.264054924249649)]



Acima temos uma lista de tuplas com as distâncias de cada palavra para nosso "resultado". Vamos ordenar isso.


```python
# Ordenando a lista de tuplas pelo segundo elemento da tupla
distancias.sort(key = lambda tup: tup[1])  
```


```python
# Agora sim
distancias
```




    [('rei', 0.1476835012435913),
     ('Madrid', 0.2988954186439514),
     ('a', 0.4737280011177063),
     ('é', 0.5998729467391968),
     ('ele', 0.651717483997345),
     ('um', 0.6919193267822266),
     ('Lisboa', 0.7098842263221741),
     ('Berlim', 0.7608835995197296),
     ('da', 0.8640673011541367),
     ('de', 0.880749024450779),
     ('homem', 0.9079287946224213),
     ('Alemanha', 0.9178348556160927),
     ('rainha', 1.04703726246953),
     ('capital', 1.1034334897994995),
     ('Portugal', 1.264054924249649),
     ('uma', 1.2741429507732391),
     ('ela', 1.3008829057216644),
     ('mulher', 1.3129161894321442),
     ('Espanha', 1.3585205674171448)]



O vetor "resultado" foi uma previsão do nosso modelo e as palavras "Madrid" e "Berlim" são as mais similares. Observe que "Berlim" é a palavra mais similar com base no conexto, uma vez que Madrid já foi usada em nossa fórmula.

Imagine que um vetor (uma flecha) sai da origem do sistema de coordenadas (Honestidade = 0 e Experiência = 0, chamaremos de ponto O) e termina no ponto X. Este vetor é usado para localizar o ponto no nosso espaço de características. Não é diferente de simplesmente dizer que X possui H = 0.4 e E = 0.2, é apenas outra maneira de ver isso.

![title](imagens/cos.png)

Se soubermos qual é o ângulo entre os vetores X e A, podemos usar uma calculadora simples e calcular a similaridade. Podemos ver pela imagem acima que os vetores de X e A estão sobre a mesma linha reta (observe as cores dos círculos na legenda), logo o ângulo entre eles é zero graus e sua similaridade é cos(0) = 1. Já para a similaridade entre X e B não sabemos o ângulo e precisamos usar uma equação. O numerador (a parte de cima da divisão) significa multiplicar os valores de Honestidade de X e B e somar com a multiplicação dos valores de Experiência de X e B.

Isso é o que faz o Word2vec. Brihante, não?

**Em que contexto aparece a palavra Lisboa?**

Aqui é como se estivéssemos usando o modelo para previsão.


```python
# Extrai o contexto
context_to_predict = get_word_vector_v('Lisboa')

# Variável com o contexto a prever
hidden = Variable(torch.from_numpy(context_to_predict)).float()

# Executa o modelo e extrai as probabilidades 
# (executar o modelo nada mais é do que multiplicar os novos dados de entrada pelos pesos aprendidos no treinamento)
a = torch.matmul(W2, hidden)
probs = F.softmax(a, dim = 0).data.numpy()

# Imprime o resultado
for context, prob in zip(palavras, probs):
    print(f'{context}: {prob}')
```

    ele: 0.0013207101728767157
    é: 0.4827747344970703
    um: 7.279550686689618e-07
    rei: 0.0001541707169963047
    ela: 8.45046088215895e-05
    uma: 5.166189680494426e-07
    rainha: 0.000911033246666193
    homem: 3.73245984519599e-06
    mulher: 6.817875259912398e-07
    Madrid: 0.0065431734547019005
    a: 0.4977463483810425
    capital: 6.276358908507973e-05
    da: 1.422565219399985e-05
    Espanha: 0.002460959367454052
    Berlim: 0.001622330630198121
    Alemanha: 0.0005251546390354633
    Lisboa: 5.838251581735676e-06
    de: 0.004155777394771576
    Portugal: 0.0016124903922900558
    

O contexto da palavra "Lisboa" é representado pelas palavras "é", "a", "Portugal".

Nosso modelo não conseguiu aprender o contexto "capital". Quem sabe você consegue otimizar o treinamento do modelo e aumentar sua precisão.

# Fim
